import { MapPin, TrendingUp, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import alHamraVillage from "@/assets/projects/al-hamra-village.jpg";
import minaAlArab from "@/assets/projects/mina-al-arab.jpg";
import alMarjanIsland from "@/assets/projects/al-marjan-island.jpg";
import mercedesBenzCity from "@/assets/projects/mercedes-benz-city.jpg";
import inaraResidence from "@/assets/projects/inara-residence.jpg";
import masaarArada from "@/assets/projects/masaar-arada.jpg";

const PropertiesSection = () => {
  const whatsappLink = "https://wa.me/971529504782?text=Hi%20Zubair,%20I'm%20interested%20in%20learning%20more%20about%20your%20featured%20properties.";

  const properties = [
    {
      image: alHamraVillage,
      title: "Al Hamra Village",
      location: "Ras Al Khaimah",
      roi: "8-12%",
      price: "From AED 525K",
      description: "Gated coastal community with beach, golf & marina",
    },
    {
      image: minaAlArab,
      title: "Mina Al Arab",
      location: "Ras Al Khaimah",
      roi: "7-10%",
      price: "From AED 500K",
      description: "Twin-island coastal destination with nature & luxury",
    },
    {
      image: alMarjanIsland,
      title: "Al Marjan Island",
      location: "Ras Al Khaimah",
      roi: "9-14%",
      price: "Premium Pricing",
      description: "Man-made island with resort & branded residences",
    },
    {
      image: mercedesBenzCity,
      title: "Mercedes-Benz City",
      location: "Meydan, Dubai",
      roi: "10-15%",
      price: "From AED 1.6M",
      description: "World's first Mercedes-Benz master-planned city",
    },
    {
      image: inaraResidence,
      title: "Inara Residence",
      location: "Dubai South",
      roi: "8-11%",
      price: "From AED 673K",
      description: "Contemporary apartments near Expo City & Airport",
    },
    {
      image: masaarArada,
      title: "Masaar by Arada",
      location: "Sharjah",
      roi: "7-10%",
      price: "From AED 1.5M",
      description: "Green-heart community with 50,000+ trees",
    },
  ];

  return (
    <section id="properties" className="section-padding">
      <div className="container-luxury">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-12 lg:mb-16">
          <p className="text-xs sm:text-sm uppercase tracking-[0.15em] sm:tracking-[0.2em] text-primary mb-3 sm:mb-4 font-medium">
            Featured Properties
          </p>
          <h2 className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 sm:mb-6 leading-tight">
            Exclusive Investment Opportunities
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base lg:text-lg px-2">
            Hand-picked properties offering exceptional value and returns across UAE
          </p>
        </div>

        {/* Properties Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {properties.map((property, index) => (
            <div 
              key={index}
              className="group relative rounded-xl overflow-hidden hover-lift"
            >
              {/* Image */}
              <div className="aspect-[4/3] overflow-hidden">
                <img 
                  src={property.image} 
                  alt={property.title}
                  width={600}
                  height={450}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
              
              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5 lg:p-6">
                {/* Location */}
                <div className="flex items-center gap-1.5 sm:gap-2 text-primary text-xs sm:text-sm mb-1.5 sm:mb-2">
                  <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span>{property.location}</span>
                </div>
                
                {/* Title */}
                <h3 className="font-serif text-lg sm:text-xl md:text-2xl font-semibold text-foreground mb-1 sm:mb-2">
                  {property.title}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-sm text-muted-foreground mb-2 sm:mb-3 line-clamp-2">
                  {property.description}
                </p>
                
                {/* Stats */}
                <div className="flex flex-wrap items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary" />
                    <span className="text-xs sm:text-sm text-foreground">ROI: {property.roi}</span>
                  </div>
                  <div className="text-xs sm:text-sm text-muted-foreground">
                    {property.price}
                  </div>
                </div>
                
                {/* CTA */}
                <Button 
                  asChild
                  variant="goldOutline" 
                  size="sm"
                  className="group/btn text-xs sm:text-sm"
                >
                  <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                    Request Details
                    <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform group-hover/btn:translate-x-1" />
                  </a>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PropertiesSection;
